extends Area2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	body_entered.connect(_on_body_entered)
	$AnimationPlayer.get_animation("new_animation").loop_mode = Animation.LOOP_LINEAR
	$AnimationPlayer.play("new_animation")


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _on_body_entered(body: Node2D) -> void:
	if body.name == "Prota":
		body.morir()
