extends Node2D

const SPEED = 300

var posicion_inicial: Vector2
@onready var bala: StaticBody2D = $bala

func _ready() -> void:
	posicion_inicial = bala.position

func _physics_process(delta: float) -> void:
	bala.position.x -= SPEED * delta

func _on_final_area_entered(area: Area2D) -> void:
	if area == $bala/Impacto:
		bala.position=posicion_inicial



func _on_impacto_body_entered(body: Node2D) -> void:
	if body.name == "Prota":
		body.morir()
