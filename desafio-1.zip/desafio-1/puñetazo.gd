extends Node2D


# Called when the node enters the scene tree for the first time.
func _physics_process(delta: float) -> void:
	if $Derecha.is_colliding():
		$AnimatedSprite2D.flip_h = false
		$Puño.position.x = 40
		$AnimatedSprite2D.play("pegar")
	elif $Izquierda.is_colliding():
		$AnimatedSprite2D.flip_h = true
		$Puño.position.x = -40
		$AnimatedSprite2D.play("pegar")
	else:
		$AnimatedSprite2D.play("idle")

	# El puño solo está activo en los frames del golpe
	var golpeando = $AnimatedSprite2D.animation == "pegar" and $AnimatedSprite2D.frame >= 2 and $AnimatedSprite2D.frame <= 3
	$Puño/CollisionShape2D.disabled = not golpeando


func _on_puño_body_entered(body: Node2D) -> void:
	if body.name == "Prota":
		body.morir()
