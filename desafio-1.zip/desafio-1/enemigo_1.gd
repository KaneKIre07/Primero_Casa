extends CharacterBody2D


const SPEED = 300.0
const JUMP_VELOCITY = -400.0


func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta
		
	
	if $Derecha.is_colliding():
		velocity.x=-SPEED
	elif not $AbajoIzquierda.is_colliding() :
		velocity.x=SPEED
	move_and_slide()


func _process(delta: float) -> void:
	if velocity.x>0:
		$AnimatedSprite2D.play("caminar")
		$AnimatedSprite2D.flip_h=false
	elif velocity.x<0:
		$AnimatedSprite2D.play("caminar")
		$AnimatedSprite2D.flip_h=true


func _on_area_2d_2_body_entered(body: Node2D) -> void:
	if body.name == "Prota":
		body.morir()
