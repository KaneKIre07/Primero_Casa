extends CharacterBody2D


const SPEED = 500.0
const JUMP_VELOCITY = -800.0

var muerto=false

func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Handle jump.
	if Input.is_action_just_pressed("ui_up") and is_on_floor() and !muerto:
		velocity.y = JUMP_VELOCITY

	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	var direction := Input.get_axis("ui_left", "ui_right")
	if direction and !muerto:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	move_and_slide()
	
func _process(delta: float) -> void:
	if muerto:
		$AnimatedSprite2D.play("muerte")
	elif velocity.x>0 and is_on_floor() :
		$AnimatedSprite2D.play("caminar")
		$AnimatedSprite2D.flip_h=false
	elif velocity.x<0 and is_on_floor() :
		$AnimatedSprite2D.play("caminar")
		$AnimatedSprite2D.flip_h=true
	elif Input.is_action_just_pressed("ui_up"):
		$AnimatedSprite2D.play("saltar")
	elif velocity.x==0 and velocity.y==0:
		$AnimatedSprite2D.play("idle")


func _on_area_2d_2_body_entered(body: Node2D) -> void:
	if body.name=="Prota" and !muerto:
		muerto=true


func morir() -> void:
	if muerto:
		return
	muerto = true
	$AnimatedSprite2D.play("muerte")
