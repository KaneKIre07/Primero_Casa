extends Node2D

const ORBITA = 2.0



# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	$AnimatedSprite2D.play("idle")


func _physics_process(delta: float) -> void:
	$Orbita.rotation += ORBITA * delta


func _on_se_muere_body_entered(body: Node2D) -> void:
	if body.name == "Prota":
		queue_free()

func _on_te_mata_body_entered(body: Node2D) -> void:
	if body.name == "Prota":
		body.morir()
